import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { FormPracticeComponent } from "./form-practice/form-practice.component";
import { DisplayDataComponent } from "./display-data/display-data.component";

const routes: Routes = [
  {
    path: "",
    component: FormPracticeComponent,
    pathMatch: "full"
  },
  {
    path: "Form",
    component: FormPracticeComponent
  },
  {
    path: "Display",
    component: DisplayDataComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
